import "./community.scss"

function Community() {
  return (
    <div className="community">
        Community
    </div>
  )
}

export default Community